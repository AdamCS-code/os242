#include <stdio.h>

int main() {
    printf("WEEK03: AdamCS-code\n");
    return 0;
}
